#pragma once
#include "Main.h"
#include <wx/wxprec.h>
#include <wx/wx.h>


wxIMPLEMENT_APP(MyApp);