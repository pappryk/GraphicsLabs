#pragma once
#include <wx/wxprec.h>
#include <wx/wx.h>
#include "MyFrame.h"



class MyApp : public wxApp
{
public:
    virtual bool OnInit();
};